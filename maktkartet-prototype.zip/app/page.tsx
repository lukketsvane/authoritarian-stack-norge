import Maktkartet from "@/components/maktkartet"

export default function Home() {
  return <Maktkartet />
}
